DELETE 
FROM animals
WHERE type = 'lion';


DELETE 
FROM animals
WHERE name LIKE 'M%';


DELETE 
FROM animals
WHERE age < 9;